import com.mongodb.client.*;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import org.bson.types.ObjectId;
import redis.clients.jedis.Jedis;

import static spark.Spark.*;

public class ReportProjectUserApi {
    private static final String MONGO_URI = "mongodb://" + System.getenv("MONGO_DATABASE_HOST") + ":" + System.getenv("MONGO_DATABASE_PORT");
    private static final MongoClient mongoClient = MongoClients.create(MONGO_URI);
    private static final Jedis redisClient = new Jedis(System.getenv("REDIS_DATABASE_HOST"), Integer.parseInt(System.getenv("REDIS_DATABASE_PORT")));

    public static void main(String[] args) {
        port(4000);

        // Get all reports
        get("/reports", (req, res) -> {
            MongoDatabase db = mongoClient.getDatabase("reporting");
            MongoCollection<Document> collection = db.getCollection("reports");
            return collection.find().into(new java.util.ArrayList<>());
        }, new JsonTransformer());

        // Get a specific project
        get("/projects/:project_id", (req, res) -> {
            String projectId = req.params("project_id");
            if (!ObjectId.isValid(projectId)) {
                res.status(400);
                return new Document("error", "Invalid project ID");
            }
            MongoDatabase db = mongoClient.getDatabase("reporting");
            MongoCollection<Document> collection = db.getCollection("projects");
            Document project = collection.find(Filters.eq("_id", new ObjectId(projectId))).first();
            if (project == null) {
                res.status(404);
                return new Document("error", "Project not found");
            }
            return project;
        }, new JsonTransformer());

        // Create a new user
        post("/users", (req, res) -> {
            MongoDatabase db = mongoClient.getDatabase("reporting");
            MongoCollection<Document> collection = db.getCollection("users");
            Document user = Document.parse(req.body());
            collection.insertOne(user);
            res.status(201);
            return user;
        }, new JsonTransformer());

        // Increment report count in Redis
        post("/reports", (req, res) -> {
            String reportCount = redisClient.get("report_count");
            int newCount = (reportCount == null) ? 1 : Integer.parseInt(reportCount) + 1;
            redisClient.set("report_count", String.valueOf(newCount));

            MongoDatabase db = mongoClient.getDatabase("reporting");
            MongoCollection<Document> collection = db.getCollection("reports");
            Document report = Document.parse(req.body());
            collection.insertOne(report);
            res.status(201);
            return report;
        }, new JsonTransformer());
    }
}
