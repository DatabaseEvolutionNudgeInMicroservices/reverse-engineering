// Constants

const express = require('express');
const bodyParser = require('body-parser');
const redis = require("redis");
const app = express();
const applicationPort = 5000;
const { MongoClient, ObjectId } = require("mongodb");

// Settings

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Database : Redis

let redisClient = redis.createClient({
    url: 'redis://' + process.env.REDIS_DATABASE_HOST + ':' + process.env.REDIS_DATABASE_PORT
});

redisClient.on('ready', () => console.log('Redis ready: ok'));
redisClient.on('error', (err) => console.log('Redis error: ' + err));
redisClient.connect();

// Database : Mongo
let mongoClient = new MongoClient('mongodb://' + process.env.MONGO_DATABASE_HOST + ':' + process.env.MONGO_DATABASE_PORT);

// Routes

// Get all tasks
app.get('/tasks', async function (request, response) {
    try {
        await mongoClient.connect();
        const db = mongoClient.db('task_management');
        const collection = db.collection('tasks');
        const documents = await collection.find({}).toArray();

        if (!documents) {
            return response.status(404).json({ error: 'Tasks not found' });
        }
        response.status(200).json(documents);
    } catch (e) {
        response.status(500).json(e.message);
    } finally {
        await mongoClient.close();
    }
});

// Get a specific team
app.get('/team/:team_id', async function (request, response) {
    try {
        const teamId = request.params.team_id;
        if (!ObjectId.isValid(teamId)) {
            return response.status(400).json({ error: 'TeamID not valid' });
        }

        await mongoClient.connect();
        const db = mongoClient.db('task_management');
        const collection = db.collection('teams');
        const document = await collection.findOne({ _id: new ObjectId(teamId) });

        if (!document) {
            return response.status(404).json({ error: 'Team not found' });
        }
        response.status(200).json(document);
    } catch (e) {
        response.status(500).json(e.message);
    } finally {
        await mongoClient.close();
    }
});

// Create a new employee
app.post('/employee', async function (request, response) {
    let employee = request.body;
    try {
        await mongoClient.connect();
        const db = mongoClient.db('task_management');
        const collection = db.collection('employees');
        const document = await collection.insertOne(employee);

        if (!document) {
            return response.status(404).json({ error: 'Employee creation failed' });
        }
        response.status(201).json(document);
    } catch (e) {
        response.status(500).json(e.message);
    } finally {
        await mongoClient.close();
    }
});

// Entry point

app.listen(applicationPort, () => {
    console.log(`Server running on port ${applicationPort}`);
});
