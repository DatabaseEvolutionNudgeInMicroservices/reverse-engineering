// Constants

const express = require('express');
const bodyParser = require('body-parser');
const redis = require("redis");
const app = express();
const applicationPort = 4000;
const { MongoClient, ObjectId } = require("mongodb");

// Settings

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Database : Redis

let redisClient = redis.createClient({
    url: 'redis://' + process.env.REDIS_DATABASE_HOST + ':' + process.env.REDIS_DATABASE_PORT
});

redisClient.on('ready', () => console.log('Redis ready: ok'));
redisClient.on('error', (err) => console.log('Redis error: ' + err));
redisClient.connect();

// Database : Mongo
let mongoClient = new MongoClient('mongodb://' + process.env.MONGO_DATABASE_HOST + ':' + process.env.MONGO_DATABASE_PORT);

// Routes

// Get all reports
app.get('/reports', async function (request, response) {
    try {
        await mongoClient.connect();
        const db = mongoClient.db('project_management');
        const collection = db.collection('reports');
        const documents = await collection.find({}).toArray();

        if (!documents) {
            return response.status(404).json({ error: 'Reports not found' });
        }
        response.status(200).json(documents);
    } catch (e) {
        response.status(500).json(e.message);
    } finally {
        await mongoClient.close();
    }
});

// Get a specific project
app.get('/project/:project_id', async function (request, response) {
    try {
        const projectId = request.params.project_id;
        if (!ObjectId.isValid(projectId)) {
            return response.status(400).json({ error: 'ProjectID not valid' });
        }

        await mongoClient.connect();
        const db = mongoClient.db('project_management');
        const collection = db.collection('projects');
        const document = await collection.findOne({ _id: new ObjectId(projectId) });

        if (!document) {
            return response.status(404).json({ error: 'Project not found' });
        }
        response.status(200).json(document);
    } catch (e) {
        response.status(500).json(e.message);
    } finally {
        await mongoClient.close();
    }
});

// Create a new user
app.post('/user', async function (request, response) {
    let user = request.body;
    try {
        await mongoClient.connect();
        const db = mongoClient.db('project_management');
        const collection = db.collection('users');
        const document = await collection.insertOne(user);

        if (!document) {
            return response.status(404).json({ error: 'User creation failed' });
        }
        response.status(201).json(document);
    } catch (e) {
        response.status(500).json(e.message);
    } finally {
        await mongoClient.close();
    }
});

// Entry point

app.listen(applicationPort, () => {
    console.log(`Server running on port ${applicationPort}`);
});
