const { MongoClient, ObjectId } = require("mongodb");

// Database : Mongo
const mongoClient = new MongoClient('mongodb://' + process.env.MONGO_DATABASE_HOST + ':' + process.env.MONGO_DATABASE_PORT);

async function manipulateDatabase() {
    try {
        await mongoClient.connect();
        const db = mongoClient.db('management_system');

        // Reports collection
        const reportsCollection = db.collection('reports');
        const newReport = { title: "Monthly Analysis", created_at: new Date(), author: "John Doe" };
        const reportInsertResult = await reportsCollection.insertOne(newReport);
        console.log("Inserted report:", reportInsertResult.insertedId);

        // Projects collection
        const projectsCollection = db.collection('projects');
        const projectId = new ObjectId();
        const newProject = { _id: projectId, name: "AI Development", status: "In Progress", team: ["Alice", "Bob"] };
        await projectsCollection.insertOne(newProject);
        console.log("Inserted project:", projectId);

        const projectUpdate = await projectsCollection.updateOne(
            { _id: projectId },
            { $set: { status: "Completed" } }
        );
        console.log("Updated project status:", projectUpdate.modifiedCount);

        // Users collection
        const usersCollection = db.collection('users');
        const newUser = { name: "Alice", email: "alice@example.com", role: "Manager" };
        const userInsertResult = await usersCollection.insertOne(newUser);
        console.log("Inserted user:", userInsertResult.insertedId);

        const foundUser = await usersCollection.findOne({ email: "alice@example.com" });
        console.log("Fetched user:", foundUser);

        const userDeletion = await usersCollection.deleteOne({ email: "alice@example.com" });
        console.log("Deleted user count:", userDeletion.deletedCount);
    } catch (e) {
        console.error("Database operation failed:", e.message);
    } finally {
        await mongoClient.close();
    }
}

manipulateDatabase();
