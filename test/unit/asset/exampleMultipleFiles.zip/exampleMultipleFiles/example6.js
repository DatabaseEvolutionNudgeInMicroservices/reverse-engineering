// Import required libraries
const { MongoClient } = require('mongodb');

// MongoDB connection URI and client setup
const uri = 'mongodb://localhost:27017';
const client = new MongoClient(uri);

// Database and collections
const dbName = 'libraryDB';
const booksCollection = 'books';
const employeesCollection = 'employees';
const townsCollection = 'towns';

async function run() {
    try {
        // Connect to MongoDB
        await client.connect();
        console.log('Connected successfully to MongoDB');

        const db = client.db(dbName);

        // Insert sample data into the collections
        await insertSampleData(db);

        // Fetch and display all books
        await fetchBooks(db);

        // Fetch employees from a specific town
        await fetchEmployeesByTown(db, 'Springfield');

        // Update a book's information
        await updateBookTitle(db, '978-3-16-148410-0', 'Updated Book Title');

        // Delete a town record
        await deleteTown(db, 'Old Town');

    } catch (error) {
        console.error('An error occurred:', error);
    } finally {
        // Close the MongoDB connection
        await client.close();
        console.log('MongoDB connection closed');
    }
}

// Function to insert sample data into the database
async function insertSampleData(db) {
    const books = db.collection(booksCollection);
    const employees = db.collection(employeesCollection);
    const towns = db.collection(townsCollection);

    await books.insertMany([
        { isbn: '978-3-16-148410-0', title: 'The Great Book', author: 'John Doe', publishedYear: 2020 },
        { isbn: '978-1-23-456789-7', title: 'Another Book', author: 'Jane Smith', publishedYear: 2018 }
    ]);

    await employees.insertMany([
        { employeeId: 1, name: 'Alice Johnson', position: 'Librarian', town: 'Springfield' },
        { employeeId: 2, name: 'Bob Williams', position: 'Assistant', town: 'Shelbyville' }
    ]);

    await towns.insertMany([
        { townName: 'Springfield', population: 30000 },
        { townName: 'Shelbyville', population: 20000 },
        { townName: 'Old Town', population: 5000 }
    ]);

    console.log('Sample data inserted successfully');
}

// Function to fetch and display all books
async function fetchBooks(db) {
    const books = db.collection(booksCollection);
    const allBooks = await books.find({}).toArray();
    console.log('Books in the database:', allBooks);
}

// Function to fetch employees by town name
async function fetchEmployeesByTown(db, townName) {
    const employees = db.collection(employeesCollection);
    const employeesInTown = await employees.find({ town: townName }).toArray();
    console.log(`Employees in ${townName}:`, employeesInTown);
}

// Function to update a book title by ISBN
async function updateBookTitle(db, isbn, newTitle) {
    const books = db.collection(booksCollection);
    const result = await books.updateOne(
        { isbn },
        { $set: { title: newTitle } }
    );

    if (result.modifiedCount > 0) {
        console.log(`Book with ISBN ${isbn} updated successfully`);
    } else {
        console.log(`No book found with ISBN ${isbn}`);
    }
}

// Function to delete a town by name
async function deleteTown(db, townName) {
    const towns = db.collection(townsCollection);
    const result = await towns.deleteOne({ townName });

    if (result.deletedCount > 0) {
        console.log(`Town '${townName}' deleted successfully`);
    } else {
        console.log(`No town found with the name '${townName}'`);
    }
}

// Run the script
run();
